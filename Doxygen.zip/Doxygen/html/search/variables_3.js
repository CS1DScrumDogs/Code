var searchData=
[
  ['name_137',['name',['../structsouvenir_item.html#a39ed37d1f5d53285c8a7628c81946a13',1,'souvenirItem::name()'],['../struct_college.html#ae8b235251d87f2e0709e90a697b0d06b',1,'College::name()']]]
];
