var searchData=
[
  ['initializedb_111',['initializeDB',['../classdb_manager.html#a6980cc0fa5fdc50934944c6f17b6980a',1,'dbManager']]]
];
