var searchData=
[
  ['delay_98',['delay',['../class_college_model.html#aec2e897e1a9e275308ed7889b7d94ef1',1,'CollegeModel']]],
  ['deletesouveniritem_99',['deleteSouvenirItem',['../classdb_manager.html#a97da73c78035103e648836dbfb927786',1,'dbManager']]],
  ['deletetransaction_100',['deleteTransaction',['../class_cart.html#a82fa9a7a845f5fde8d88999a11159d27',1,'Cart']]]
];
