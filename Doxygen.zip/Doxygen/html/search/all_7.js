var searchData=
[
  ['operator_3c_37',['operator&lt;',['../struct_college.html#a6cdcaec6e39c48a6f42f4e908aa04d95',1,'College::operator&lt;(const College &amp;otherCollege) const'],['../struct_college.html#a6cdcaec6e39c48a6f42f4e908aa04d95',1,'College::operator&lt;(const College &amp;otherCollege) const']]],
  ['operator_3d_3d_38',['operator==',['../class_transaction.html#af91c48f0072425f2c65cb3689ca6c653',1,'Transaction']]]
];
