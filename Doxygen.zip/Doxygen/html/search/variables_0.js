var searchData=
[
  ['college_131',['college',['../class_transaction.html#a8789961780bef7d71a64eb894fb57d84',1,'Transaction']]]
];
