var searchData=
[
  ['souveniritems_140',['souvenirItems',['../struct_college.html#a67a028d6ebf422847d8fbec6318b1b00',1,'College']]]
];
