var searchData=
[
  ['cart_4',['Cart',['../class_cart.html',1,'']]],
  ['clearwidgets_5',['clearWidgets',['../class_college_model.html#adad9674dbee23e82f64508cd1cfe2670',1,'CollegeModel']]],
  ['closedatabase_6',['closeDatabase',['../classdb_manager.html#a4170bc104b663300dee1fd7390a6ae63',1,'dbManager']]],
  ['college_7',['College',['../struct_college.html',1,'College'],['../struct_college.html#a99fcfec7020b9c21aa202a496397ec57',1,'College::College(int id, QString name, double distanceToSaddleback, QVector&lt; souvenirItem &gt; items)'],['../struct_college.html#a99fcfec7020b9c21aa202a496397ec57',1,'College::College(int id, QString name, double distanceToSaddleback, QVector&lt; souvenirItem &gt; items)'],['../class_transaction.html#a8789961780bef7d71a64eb894fb57d84',1,'Transaction::college()']]],
  ['collegeclickedsignal_8',['collegeClickedSignal',['../class_main_window.html#ad176d91de00423f54f2d9eaabff52975',1,'MainWindow']]],
  ['collegemodel_9',['CollegeModel',['../class_college_model.html',1,'CollegeModel'],['../class_ui_1_1_college_model.html',1,'Ui::CollegeModel'],['../class_college_model.html#a028e4ea98b27a8d5fffafdb69a1d9e2d',1,'CollegeModel::CollegeModel()']]],
  ['confirmpurchase_10',['confirmPurchase',['../class_college_model.html#a0bf105af39d44c58b7acfc4600f739cf',1,'CollegeModel']]],
  ['collegetour_11',['CollegeTour',['../md__c_1__users__patrick__moir__desktop__college__touring__project__college_touring_project__r_e_a_d_m_e.html',1,'']]]
];
