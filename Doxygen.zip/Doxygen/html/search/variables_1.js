var searchData=
[
  ['destinationcollege_5fid_132',['destinationCollege_ID',['../struct_distance.html#a11eea19a1d9b2dc334ea53101994a6f0',1,'Distance']]],
  ['distanceto_133',['distanceTo',['../struct_distance.html#a40bfd91b41ac3e5c6fd58e7c0ac4f3a6',1,'Distance']]],
  ['distancetosaddleback_134',['distanceToSaddleback',['../struct_college.html#a173efd43af4e173b2a77ba1054d91374',1,'College']]]
];
