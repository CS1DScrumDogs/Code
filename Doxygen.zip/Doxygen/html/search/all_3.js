var searchData=
[
  ['getcollegebyid_20',['getCollegeByID',['../classdb_manager.html#a1ad8ef74ddb1a0022a1598ef9e60cd6f',1,'dbManager']]],
  ['getcolleges_21',['getColleges',['../classdb_manager.html#aad9d2f24ac9c74728393502b6c04a0b8',1,'dbManager']]],
  ['getdistancesfrom_22',['getDistancesFrom',['../classdb_manager.html#aaa56ad9c1a84cd0063efa1551b297138',1,'dbManager']]],
  ['getinstance_23',['getInstance',['../classdb_manager.html#a0b96aeab4f66563db74711be1dfc1edb',1,'dbManager']]],
  ['getpurchases_24',['getPurchases',['../class_cart.html#a3d7b1086c3a0ee0e9ae9c004f80fbc69',1,'Cart']]],
  ['getsouvenirbyid_25',['getSouvenirByID',['../classdb_manager.html#a005ba0700501bd4c601a79248607f2b6',1,'dbManager']]],
  ['getsouvenirsbycollegeid_26',['getSouvenirsByCollegeID',['../classdb_manager.html#a91281dfbeb41cebfa8a633e3a7e12a5e',1,'dbManager']]],
  ['gettotal_27',['getTotal',['../class_cart.html#a86b4dda9ec906b2949248ce1085285e1',1,'Cart']]],
  ['gettotalcolleges_28',['getTotalColleges',['../classdb_manager.html#ae211811d8431bd57bd250c2ab753f691',1,'dbManager']]],
  ['gettriplength_29',['getTripLength',['../class_college_model.html#ab621eb530418fdcbd35a88911881504f',1,'CollegeModel']]]
];
