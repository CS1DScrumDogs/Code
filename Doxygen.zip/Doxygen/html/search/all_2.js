var searchData=
[
  ['dbmanager_12',['dbManager',['../classdb_manager.html',1,'']]],
  ['delay_13',['delay',['../class_college_model.html#aec2e897e1a9e275308ed7889b7d94ef1',1,'CollegeModel']]],
  ['deletesouveniritem_14',['deleteSouvenirItem',['../classdb_manager.html#a97da73c78035103e648836dbfb927786',1,'dbManager']]],
  ['deletetransaction_15',['deleteTransaction',['../class_cart.html#a82fa9a7a845f5fde8d88999a11159d27',1,'Cart']]],
  ['destinationcollege_5fid_16',['destinationCollege_ID',['../struct_distance.html#a11eea19a1d9b2dc334ea53101994a6f0',1,'Distance']]],
  ['distance_17',['Distance',['../struct_distance.html',1,'']]],
  ['distanceto_18',['distanceTo',['../struct_distance.html#a40bfd91b41ac3e5c6fd58e7c0ac4f3a6',1,'Distance']]],
  ['distancetosaddleback_19',['distanceToSaddleback',['../struct_college.html#a173efd43af4e173b2a77ba1054d91374',1,'College']]]
];
