var searchData=
[
  ['addcollege_0',['addCollege',['../classdb_manager.html#ae466201599ce67617d769a1196714bf1',1,'dbManager']]],
  ['addsouveniritem_1',['addSouvenirItem',['../classdb_manager.html#aa52b30e936de3c8c7b561c6d6c6a4cd6',1,'dbManager']]],
  ['addtransaction_2',['addTransaction',['../class_cart.html#a751f19cb4df33a6a8c89f7e752cdb07d',1,'Cart']]],
  ['authenticateadminloginrequest_3',['authenticateAdminLoginRequest',['../classdb_manager.html#a0ce2c2fa322e30e512165509811544fa',1,'dbManager']]]
];
