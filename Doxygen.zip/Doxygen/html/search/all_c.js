var searchData=
[
  ['totals_53',['totals',['../class_ui_1_1totals.html',1,'Ui']]],
  ['totalssheet_54',['totalsSheet',['../classtotals_sheet.html',1,'totalsSheet'],['../class_ui_1_1totals_sheet.html',1,'Ui::totalsSheet'],['../classtotals_sheet.html#ab5b948f0b74c26fd822be62606d6ac35',1,'totalsSheet::totalsSheet()']]],
  ['transaction_55',['Transaction',['../class_transaction.html',1,'Transaction'],['../class_transaction.html#a027ee3210228e05081452160100a65df',1,'Transaction::Transaction()']]]
];
