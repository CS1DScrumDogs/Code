var searchData=
[
  ['totals_79',['totals',['../class_ui_1_1totals.html',1,'Ui']]],
  ['totalssheet_80',['totalsSheet',['../classtotals_sheet.html',1,'totalsSheet'],['../class_ui_1_1totals_sheet.html',1,'Ui::totalsSheet']]],
  ['transaction_81',['Transaction',['../class_transaction.html',1,'']]]
];
