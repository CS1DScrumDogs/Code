var searchData=
[
  ['dbmanager_71',['dbManager',['../classdb_manager.html',1,'']]],
  ['distance_72',['Distance',['../struct_distance.html',1,'']]]
];
