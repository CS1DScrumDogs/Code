var searchData=
[
  ['id_135',['id',['../structsouvenir_item.html#af15cfc3c9a9ad28a32c95c9eb9632e13',1,'souvenirItem::id()'],['../struct_college.html#ac843c7eba029693454852fddeaeeb9b4',1,'College::id()']]],
  ['itempurchased_136',['itemPurchased',['../class_transaction.html#a2526fe971714943e90457cc9bce61b56',1,'Transaction']]]
];
