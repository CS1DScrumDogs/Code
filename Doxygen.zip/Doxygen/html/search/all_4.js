var searchData=
[
  ['id_30',['id',['../structsouvenir_item.html#af15cfc3c9a9ad28a32c95c9eb9632e13',1,'souvenirItem::id()'],['../struct_college.html#ac843c7eba029693454852fddeaeeb9b4',1,'College::id()']]],
  ['initializedb_31',['initializeDB',['../classdb_manager.html#a6980cc0fa5fdc50934944c6f17b6980a',1,'dbManager']]],
  ['itempurchased_32',['itemPurchased',['../class_transaction.html#a2526fe971714943e90457cc9bce61b56',1,'Transaction']]]
];
